const tailwindcss = require("tailwindcss");

module.exports = {
  plugins: [
    tailwindcss,
    // autoprefixer,
  ],
};
