<template>
  <div>
    <!-- ====== Hero Section Start -->
    <div
      id="home"
      class="overflow-hidden pt-[120px] md:pt-[130px] lg:pt-[160px]"
      style="background-color: #d8d5d2"
    >
      <div class="container">
        <div class="-mx-4 flex flex-wrap items-center">
          <div class="w-full px-4">
            <div
              class="
                hero-content
                wow
                fadeInUp
                mx-auto
                max-w-[780px]
                text-center
              "
              data-wow-delay=".2s"
            >
              <!-- <h1
                class="
                  mb-8
                  text-3xl
                  font-bold
                  leading-snug
                  text-white
                  sm:text-4xl sm:leading-snug
                  md:text-[45px] md:leading-snug
                "
              >
                행복한 집, Happy House
              </h1> -->
              <p
                class="
                  mx-auto
                  mb-10
                  max-w-[700px]
                  text-base text-[#e4e4e4]
                  sm:text-2xl sm:leading-relaxed
                  md:text-2xl md:leading-relaxed
                  font-bold
                "
                style="color: #786d64"
              >
                <img
                  style=" width=100%"
                  src="../../../src/assets/img/main/main_lang.png"
                />
              </p>
              <!-- <div>
                <img src="../../../src/assets/img/main_lang" />
              </div> -->
              <!-- <div class="flex flex-wrap">
                <div class="w-full px-4 md:w-1/2 lg:w-1/3">
                  <div
                    style="border-radius: 20px"
                    class="
                      ud-single-testimonial
                      wow
                      fadeInUp
                      mb-12
                      shadow-testimonial
                    "
                    data-wow-delay=".1s
              "
                  >
                    <div class="ud-testimonial-ratings items-center"></div>
                    <div class="ud-testimonial-content">
                      <img
                        style="border-radius: 20px"
                        class="
                          .image-thumbnail
                          mx-auto
                          max-w-full
                          rounded-t-xl rounded-tr-xl
                        "
                        src="../../../public/assets/images/home/home1.png"
                      />
                    </div>
                  </div>
                </div>

                <div class="w-full px-4 md:w-1/2 lg:w-1/3">
                  <div
                    style="border-radius: 20px"
                    class="
                      ud-single-testimonial
                      wow
                      fadeInUp
                      mb-12
                      shadow-testimonial
                    "
                    data-wow-delay=".1s
              "
                  >
                    <div class="ud-testimonial-ratings items-center"></div>
                    <div class="ud-testimonial-content">
                      <img
                        style="border-radius: 20px"
                        class="
                          .image-thumbnail
                          mx-auto
                          max-w-full
                          rounded-t-xl rounded-tr-xl
                        "
                        src="../../../public/assets/images/home/home2.png"
                      />
                    </div>
                  </div>
                </div>

                <div class="w-full px-4 md:w-1/2 lg:w-1/3">
                  <div
                    style="border-radius: 20px"
                    class="
                      ud-single-testimonial
                      wow
                      fadeInUp
                      mb-12
                      shadow-testimonial
                    "
                    data-wow-delay=".1s
              "
                  >
                    <div class="ud-testimonial-ratings flex items-center"></div>
                    <div class="ud-testimonial-content">
                      <img
                        style="border-radius: 20px"
                        class="
                          .image-thumbnail
                          mx-auto
                          max-w-full
                          rounded-t-xl rounded-tr-xl
                        "
                        src="../../../public/assets/images/home/home3.png"
                      />
                    </div>
                  </div>
                </div>
              </div> -->

              <div class="wow fadeInUp text-center" data-wow-delay=".3s">
                <!-- <p
                  class="
                    mx-auto
                    max-w-[600px]
                    text-base text-[#e4e4e4]
                    ease-in-out
                    hover:opacity-100
                    sm:text-lg sm:leading-relaxed
                    md:text-xl md:leading-relaxed
                  "
                >
                  "우리" 집을 이 곳 "Happy House" 에서 찾아보세요.
                </p> -->
                <!-- <img
                  src="../../../public/assets/images/hero/brand.svg"
                  alt="image"
                  class="mx-auto w-full max-w-[250px] opacity-50 transition duration-300 ease-in-out hover:opacity-100"
                /> -->
              </div>
            </div>
          </div>

          <!-- ////////////////////////////////////////////////////// -->
          <div class="w-full rounded-t-xl rounded-tr-xl px-4">
            <div
              style="height: 400px"
              class="
                wow
                fadeInUp
                relative
                z-10
                mx-auto
                max-w-[845px]
                rounded-t-xl rounded-tr-xl
              "
              data-wow-delay=".25s"
            >
              <div class="mt-16 rounded-t-xl rounded-tr-xl">
                <hooper
                  style="height: 500px"
                  class="rounded-t-xl rounded-tr-xl"
                >
                  <slide>
                    <img
                      style="height: 380px; width: 700px; border-radius: 20px"
                      src="../../../src/assets/img/main/house/house1.jpg"
                      alt="hero"
                      class="mx-auto max-w-full rounded-t-xl rounded-tr-xl"
                    />
                  </slide>
                  <slide>
                    <img
                      style="height: 380px; width: 700px; border-radius: 20px"
                      src="../../../src/assets/img/main/house/house2.jpg"
                      alt="hero"
                      class="mx-auto max-w-full rounded-t-xl rounded-tr-xl"
                    />
                  </slide>
                  <slide>
                    <img
                      style="height: 380px; width: 700px; border-radius: 20px"
                      src="../../../src/assets/img/main/house/house3.jpg"
                      alt="hero"
                      class="mx-auto max-w-full rounded-t-xl rounded-tr-xl"
                    />
                  </slide>
                  <slide>
                    <img
                      style="height: 380px; width: 700px; border-radius: 20px"
                      src="../../../src/assets/img/main/house/house4.jpg"
                      alt="hero"
                      class="mx-auto max-w-full rounded-t-xl rounded-tr-xl"
                    />
                  </slide>
                  <slide>
                    <img
                      style="height: 380px; width: 700px; border-radius: 20px"
                      src="../../../src/assets/img/main/house/house5.jpg"
                      alt="hero"
                      class="mx-auto max-w-full rounded-t-xl rounded-tr-xl"
                    />
                  </slide>
                </hooper>
              </div>

              <div class="absolute bottom-0 -left-9 z-[-1]">
                <svg
                  width="134"
                  height="106"
                  viewBox="0 0 134 106"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle
                    cx="1.66667"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 1.66667 104)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 16.3333 104)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 31 104)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 45.6667 104)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 60.3333 104)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 88.6667 104)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 117.667 104)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 74.6667 104)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 103 104)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 132 104)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="89.3333"
                    r="1.66667"
                    transform="rotate(-90 1.66667 89.3333)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="89.3333"
                    r="1.66667"
                    transform="rotate(-90 16.3333 89.3333)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="89.3333"
                    r="1.66667"
                    transform="rotate(-90 31 89.3333)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="89.3333"
                    r="1.66667"
                    transform="rotate(-90 45.6667 89.3333)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="89.3338"
                    r="1.66667"
                    transform="rotate(-90 60.3333 89.3338)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="89.3338"
                    r="1.66667"
                    transform="rotate(-90 88.6667 89.3338)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="89.3338"
                    r="1.66667"
                    transform="rotate(-90 117.667 89.3338)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="89.3338"
                    r="1.66667"
                    transform="rotate(-90 74.6667 89.3338)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="89.3338"
                    r="1.66667"
                    transform="rotate(-90 103 89.3338)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="89.3338"
                    r="1.66667"
                    transform="rotate(-90 132 89.3338)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="74.6673"
                    r="1.66667"
                    transform="rotate(-90 1.66667 74.6673)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="31.0003"
                    r="1.66667"
                    transform="rotate(-90 1.66667 31.0003)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 16.3333 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="31.0003"
                    r="1.66667"
                    transform="rotate(-90 16.3333 31.0003)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 31 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="31.0003"
                    r="1.66667"
                    transform="rotate(-90 31 31.0003)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 45.6667 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="31.0003"
                    r="1.66667"
                    transform="rotate(-90 45.6667 31.0003)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 60.3333 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="31.0001"
                    r="1.66667"
                    transform="rotate(-90 60.3333 31.0001)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 88.6667 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="31.0001"
                    r="1.66667"
                    transform="rotate(-90 88.6667 31.0001)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 117.667 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="31.0001"
                    r="1.66667"
                    transform="rotate(-90 117.667 31.0001)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 74.6667 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="31.0001"
                    r="1.66667"
                    transform="rotate(-90 74.6667 31.0001)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 103 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="31.0001"
                    r="1.66667"
                    transform="rotate(-90 103 31.0001)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 132 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="31.0001"
                    r="1.66667"
                    transform="rotate(-90 132 31.0001)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 1.66667 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 1.66667 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 16.3333 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 16.3333 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 31 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 31 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 45.6667 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 45.6667 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 60.3333 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 60.3333 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 88.6667 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 88.6667 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 117.667 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 117.667 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 74.6667 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 74.6667 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 103 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 103 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 132 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 132 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="45.3336"
                    r="1.66667"
                    transform="rotate(-90 1.66667 45.3336)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="1.66683"
                    r="1.66667"
                    transform="rotate(-90 1.66667 1.66683)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="45.3336"
                    r="1.66667"
                    transform="rotate(-90 16.3333 45.3336)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="1.66683"
                    r="1.66667"
                    transform="rotate(-90 16.3333 1.66683)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="45.3336"
                    r="1.66667"
                    transform="rotate(-90 31 45.3336)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="1.66683"
                    r="1.66667"
                    transform="rotate(-90 31 1.66683)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="45.3336"
                    r="1.66667"
                    transform="rotate(-90 45.6667 45.3336)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="1.66683"
                    r="1.66667"
                    transform="rotate(-90 45.6667 1.66683)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="45.3338"
                    r="1.66667"
                    transform="rotate(-90 60.3333 45.3338)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="1.66707"
                    r="1.66667"
                    transform="rotate(-90 60.3333 1.66707)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="45.3338"
                    r="1.66667"
                    transform="rotate(-90 88.6667 45.3338)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="1.66707"
                    r="1.66667"
                    transform="rotate(-90 88.6667 1.66707)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="45.3338"
                    r="1.66667"
                    transform="rotate(-90 117.667 45.3338)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="1.66707"
                    r="1.66667"
                    transform="rotate(-90 117.667 1.66707)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="45.3338"
                    r="1.66667"
                    transform="rotate(-90 74.6667 45.3338)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="1.66707"
                    r="1.66667"
                    transform="rotate(-90 74.6667 1.66707)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="45.3338"
                    r="1.66667"
                    transform="rotate(-90 103 45.3338)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="1.66707"
                    r="1.66667"
                    transform="rotate(-90 103 1.66707)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="45.3338"
                    r="1.66667"
                    transform="rotate(-90 132 45.3338)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="1.66707"
                    r="1.66667"
                    transform="rotate(-90 132 1.66707)"
                    fill="white"
                  />
                </svg>
              </div>
              <div class="absolute -top-6 -right-6 z-[-1]">
                <svg
                  width="134"
                  height="106"
                  viewBox="0 0 134 106"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle
                    cx="1.66667"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 1.66667 104)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 16.3333 104)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 31 104)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 45.6667 104)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 60.3333 104)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 88.6667 104)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 117.667 104)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 74.6667 104)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 103 104)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="104"
                    r="1.66667"
                    transform="rotate(-90 132 104)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="89.3333"
                    r="1.66667"
                    transform="rotate(-90 1.66667 89.3333)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="89.3333"
                    r="1.66667"
                    transform="rotate(-90 16.3333 89.3333)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="89.3333"
                    r="1.66667"
                    transform="rotate(-90 31 89.3333)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="89.3333"
                    r="1.66667"
                    transform="rotate(-90 45.6667 89.3333)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="89.3338"
                    r="1.66667"
                    transform="rotate(-90 60.3333 89.3338)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="89.3338"
                    r="1.66667"
                    transform="rotate(-90 88.6667 89.3338)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="89.3338"
                    r="1.66667"
                    transform="rotate(-90 117.667 89.3338)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="89.3338"
                    r="1.66667"
                    transform="rotate(-90 74.6667 89.3338)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="89.3338"
                    r="1.66667"
                    transform="rotate(-90 103 89.3338)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="89.3338"
                    r="1.66667"
                    transform="rotate(-90 132 89.3338)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="74.6673"
                    r="1.66667"
                    transform="rotate(-90 1.66667 74.6673)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="31.0003"
                    r="1.66667"
                    transform="rotate(-90 1.66667 31.0003)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 16.3333 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="31.0003"
                    r="1.66667"
                    transform="rotate(-90 16.3333 31.0003)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 31 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="31.0003"
                    r="1.66667"
                    transform="rotate(-90 31 31.0003)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 45.6667 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="31.0003"
                    r="1.66667"
                    transform="rotate(-90 45.6667 31.0003)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 60.3333 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="31.0001"
                    r="1.66667"
                    transform="rotate(-90 60.3333 31.0001)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 88.6667 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="31.0001"
                    r="1.66667"
                    transform="rotate(-90 88.6667 31.0001)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 117.667 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="31.0001"
                    r="1.66667"
                    transform="rotate(-90 117.667 31.0001)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 74.6667 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="31.0001"
                    r="1.66667"
                    transform="rotate(-90 74.6667 31.0001)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 103 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="31.0001"
                    r="1.66667"
                    transform="rotate(-90 103 31.0001)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="74.6668"
                    r="1.66667"
                    transform="rotate(-90 132 74.6668)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="31.0001"
                    r="1.66667"
                    transform="rotate(-90 132 31.0001)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 1.66667 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 1.66667 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 16.3333 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 16.3333 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 31 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 31 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 45.6667 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 45.6667 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 60.3333 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 60.3333 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 88.6667 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 88.6667 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 117.667 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 117.667 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 74.6667 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 74.6667 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 103 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 103 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="60.0003"
                    r="1.66667"
                    transform="rotate(-90 132 60.0003)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="16.3336"
                    r="1.66667"
                    transform="rotate(-90 132 16.3336)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="45.3336"
                    r="1.66667"
                    transform="rotate(-90 1.66667 45.3336)"
                    fill="white"
                  />
                  <circle
                    cx="1.66667"
                    cy="1.66683"
                    r="1.66667"
                    transform="rotate(-90 1.66667 1.66683)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="45.3336"
                    r="1.66667"
                    transform="rotate(-90 16.3333 45.3336)"
                    fill="white"
                  />
                  <circle
                    cx="16.3333"
                    cy="1.66683"
                    r="1.66667"
                    transform="rotate(-90 16.3333 1.66683)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="45.3336"
                    r="1.66667"
                    transform="rotate(-90 31 45.3336)"
                    fill="white"
                  />
                  <circle
                    cx="31"
                    cy="1.66683"
                    r="1.66667"
                    transform="rotate(-90 31 1.66683)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="45.3336"
                    r="1.66667"
                    transform="rotate(-90 45.6667 45.3336)"
                    fill="white"
                  />
                  <circle
                    cx="45.6667"
                    cy="1.66683"
                    r="1.66667"
                    transform="rotate(-90 45.6667 1.66683)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="45.3338"
                    r="1.66667"
                    transform="rotate(-90 60.3333 45.3338)"
                    fill="white"
                  />
                  <circle
                    cx="60.3333"
                    cy="1.66707"
                    r="1.66667"
                    transform="rotate(-90 60.3333 1.66707)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="45.3338"
                    r="1.66667"
                    transform="rotate(-90 88.6667 45.3338)"
                    fill="white"
                  />
                  <circle
                    cx="88.6667"
                    cy="1.66707"
                    r="1.66667"
                    transform="rotate(-90 88.6667 1.66707)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="45.3338"
                    r="1.66667"
                    transform="rotate(-90 117.667 45.3338)"
                    fill="white"
                  />
                  <circle
                    cx="117.667"
                    cy="1.66707"
                    r="1.66667"
                    transform="rotate(-90 117.667 1.66707)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="45.3338"
                    r="1.66667"
                    transform="rotate(-90 74.6667 45.3338)"
                    fill="white"
                  />
                  <circle
                    cx="74.6667"
                    cy="1.66707"
                    r="1.66667"
                    transform="rotate(-90 74.6667 1.66707)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="45.3338"
                    r="1.66667"
                    transform="rotate(-90 103 45.3338)"
                    fill="white"
                  />
                  <circle
                    cx="103"
                    cy="1.66707"
                    r="1.66667"
                    transform="rotate(-90 103 1.66707)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="45.3338"
                    r="1.66667"
                    transform="rotate(-90 132 45.3338)"
                    fill="white"
                  />
                  <circle
                    cx="132"
                    cy="1.66707"
                    r="1.66667"
                    transform="rotate(-90 132 1.66707)"
                    fill="white"
                  />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- ====== Hero Section End -->

    <!-- ====== Features Section Start -->
    <div class="container">
      <div class="-mx-4 flex flex-wrap">
        <div class="w-full px-4">
          <div class="max-w-[620px]">
            <span
              class="mb-2 block text-lg font-semibold"
              sytle="color:#786d64"
            >
              NEWS
            </span>
            <h2
              class="text-3xl font-bold sm:text-4xl md:text-[42px]"
              style="color: #786d64"
            >
              Today's Main News
            </h2>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="wow fadeInUp bg-white" data-wow-delay=".2s">
          <div class="-mx-4 flex flex-wrap">
            <div class="w-full px-4">
              <div
                class="
                  items-center
                  justify-between
                  overflow-hidden
                  border
                  lg:flex
                "
              >
                <div
                  class="
                    w-full
                    py-12
                    px-7
                    sm:px-12
                    md:p-16
                    lg:max-w-[565px] lg:py-9 lg:px-16
                    xl:max-w-[640px] xl:p-[70px]
                  "
                >
                  <span
                    class="
                      mb-5
                      inline-block
                      py-2
                      px-5
                      text-sm
                      font-medium
                      text-white
                    "
                    style="background-color: #786d64"
                  >
                    매일 경제(5월 27일)
                  </span>
                  <h2
                    class="
                      mb-6
                      text-3xl
                      font-bold
                      text-dark
                      sm:text-4xl sm:leading-snug
                      2xl:text-[40px]
                    "
                  >
                    서울 아파트 매물 6만건 쌓이는데,,, 거래는 여전히 찬바람
                  </h2>
                  <p class="mb-9 text-base leading-relaxed text-body-color">
                    서울 아파트시장 관망세가 지속되고 있다. 지난 3월 대통령 선거
                    이후 매물이 눈에 띄게 증가하고 있지만 거래는 좀처럼 회복
                    조짐을 보이지 않고 있다. 24일 부동산 빅데이터업체 아실에
                    따르면 이날 기준 서울 아파트 매물은 6만486건을 기록했다.
                    대선이 치러진 지난 3월 9일 5만131건 대비 20.7%(1만355건)
                    증가했다.
                  </p>
                  <p class="mb-9 text-base leading-relaxed text-body-color">
                    윤석열 대통령이 취임한 이후 다주택자 양도세 완화가 이뤄진
                    지난 10일과 비교해도 매물은 큰 폭으로 증가했다. 지난 10일
                    매물 5만6568건 대비 서울 아파트는 7%(3918건) 증가했다.
                  </p>
                  <a
                    href="https://www.mk.co.kr/news/realestate/view/2022/05/458815/"
                    target="_blank"
                    class="
                      inline-flex
                      items-center
                      justify-center
                      rounded
                      py-4
                      px-6
                      text-base
                      font-medium
                      text-white
                      transition
                      duration-300
                      ease-in-out
                      hover:bg-opacity-90 hover:shadow-lg
                    "
                    style="background-color: #786d64"
                  >
                    뉴스 보러가기
                  </a>
                </div>
                <div class="text-center">
                  <div class="relative z-10 inline-block">
                    <img
                      src="../../../public/assets/images/news/apt.png"
                      alt="image"
                      class="mx-auto lg:ml-auto"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <br />
      <span class="mb-2 block text-lg font-semibold" style="color: #786d64">
        다양한 뉴스
      </span>

      <div class="-mx-4 flex flex-wrap">
        <div class="w-full px-4 md:w-1/2 lg:w-1/4">
          <div class="wow fadeInUp group mb-12 bg-white" data-wow-delay=".1s">
            <div
              class="
                relative
                z-10
                mb-8
                flex
                h-[70px]
                w-[70px]
                items-center
                justify-center
                rounded-2xl
              "
              style="background-color: #786d64"
            >
              <span
                class="
                  absolute
                  top-0
                  left-0
                  z-[-1]
                  mb-8
                  flex
                  h-[70px]
                  w-[70px]
                  rotate-[25deg]
                  items-center
                  justify-center
                  rounded-2xl
                  bg-opacity-20
                  duration-300
                  group-hover:rotate-45
                "
                style="background-color: #786d64"
              ></span>
              <span class="mb-2 block text-lg font-semibold text-white">
                경제
              </span>
            </div>
            <h4 class="mb-3 text-xl font-bold text-dark">
              기대인플레이션율 9년7개월만에 최고
            </h4>
            <p class="mb-8 text-body-color lg:mb-11">
              한국은행이 24일 발표한 '5월 소비자동향조사' 결과에 따르면
              기대인플레이션율은 3.3%로 집계된다...
            </p>
            <a
              target="_blank"
              href="https://www.mk.co.kr/news/economy/view/2022/05/458974/"
              class="text-base font-medium text-body-color hover:text-primary"
            >
              뉴스 보러 가기
            </a>
          </div>
        </div>
        <div class="w-full px-4 md:w-1/2 lg:w-1/4">
          <div class="wow fadeInUp group mb-12 bg-white" data-wow-delay=".15s">
            <div
              class="
                relative
                z-10
                mb-8
                flex
                h-[70px]
                w-[70px]
                items-center
                justify-center
                rounded-2xl
              "
              style="background-color: #786d64"
            >
              <span
                class="
                  absolute
                  top-0
                  left-0
                  z-[-1]
                  mb-8
                  flex
                  h-[70px]
                  w-[70px]
                  rotate-[25deg]
                  items-center
                  justify-center
                  rounded-2xl
                  bg-opacity-20
                  duration-300
                  group-hover:rotate-45
                "
                style="background-color: #786d64"
              ></span>
              <span class="mb-2 block text-lg font-semibold text-white">
                기업
              </span>
            </div>
            <h4 class="mb-3 text-xl font-bold text-dark">
              다시 뛰는 재계..국민 박수 받는 날 올 것
            </h4>
            <p class="mb-8 text-body-color lg:mb-11">
              대한상공회의소가 한국 재계를 대표해 '신기업가정신'을 선포하고 이를
              실천하기 위한 신기업가정신협의회를 출범시켰다.
            </p>
            <a
              target="_blank"
              href="https://www.mk.co.kr/news/business/view/2022/05/458838/"
              class="text-base font-medium text-body-color hover:text-primary"
            >
              뉴스 보러 가기
            </a>
          </div>
        </div>
        <div class="w-full px-4 md:w-1/2 lg:w-1/4">
          <div class="wow fadeInUp group mb-12 bg-white" data-wow-delay=".2s">
            <div
              class="
                relative
                z-10
                mb-8
                flex
                h-[70px]
                w-[70px]
                items-center
                justify-center
                rounded-2xl
              "
              style="background-color: #786d64"
            >
              <span
                class="
                  absolute
                  top-0
                  left-0
                  z-[-1]
                  mb-8
                  flex
                  h-[70px]
                  w-[70px]
                  rotate-[25deg]
                  items-center
                  justify-center
                  rounded-2xl
                  bg-opacity-20
                  duration-300
                  group-hover:rotate-45
                "
                style="background-color: #786d64"
              ></span>
              <span class="mb-2 block text-lg font-semibold text-white">
                사회
              </span>
              <path
                d="M10.7734 14.3281H3.82813C2.07813 14.3281 0.65625 12.9062 0.65625 11.1562V4.21094C0.65625 2.46094 2.07813 1.03906 3.82813 1.03906H10.7734C12.5234 1.03906 13.9453 2.46094 13.9453 4.21094V11.1562C13.9453 12.9062 12.5234 14.3281 10.7734 14.3281ZM3.82813 2.95312C3.17188 2.95312 2.57031 3.5 2.57031 4.21094V11.1562C2.57031 11.8125 3.11719 12.4141 3.82813 12.4141H10.7734C11.4297 12.4141 12.0313 11.8672 12.0313 11.1562V4.21094C12.0313 3.55469 11.4844 2.95312 10.7734 2.95312H3.82813Z"
                fill="white"
              />
              <path
                d="M31.1719 14.3281H24.2266C22.4766 14.3281 21.0547 12.9062 21.0547 11.1562V4.21094C21.0547 2.46094 22.4766 1.03906 24.2266 1.03906H31.1719C32.9219 1.03906 34.3438 2.46094 34.3438 4.21094V11.1562C34.3438 12.9062 32.9219 14.3281 31.1719 14.3281ZM24.2266 2.95312C23.5703 2.95312 22.9688 3.5 22.9688 4.21094V11.1562C22.9688 11.8125 23.5156 12.4141 24.2266 12.4141H31.1719C31.8281 12.4141 32.4297 11.8672 32.4297 11.1562V4.21094C32.4297 3.55469 31.8828 2.95312 31.1719 2.95312H24.2266Z"
                fill="white"
              />
              <path
                d="M10.7734 33.9609H3.82813C2.07813 33.9609 0.65625 32.5391 0.65625 30.7891V23.8438C0.65625 22.0938 2.07813 20.6719 3.82813 20.6719H10.7734C12.5234 20.6719 13.9453 22.0938 13.9453 23.8438V30.7891C13.9453 32.5391 12.5234 33.9609 10.7734 33.9609ZM3.82813 22.5859C3.17188 22.5859 2.57031 23.1328 2.57031 23.8438V30.7891C2.57031 31.4453 3.11719 32.0469 3.82813 32.0469H10.7734C11.4297 32.0469 12.0313 31.5 12.0313 30.7891V23.8438C12.0313 23.1875 11.4844 22.5859 10.7734 22.5859H3.82813Z"
                fill="white"
              />
              <path
                d="M31.1719 33.9609H24.2266C22.4766 33.9609 21.0547 32.5391 21.0547 30.7891V23.8438C21.0547 22.0938 22.4766 20.6719 24.2266 20.6719H31.1719C32.9219 20.6719 34.3438 22.0938 34.3438 23.8438V30.7891C34.3438 32.5391 32.9219 33.9609 31.1719 33.9609ZM24.2266 22.5859C23.5703 22.5859 22.9688 23.1328 22.9688 23.8438V30.7891C22.9688 31.4453 23.5156 32.0469 24.2266 32.0469H31.1719C31.8281 32.0469 32.4297 31.5 32.4297 30.7891V23.8438C32.4297 23.1875 31.8828 22.5859 31.1719 22.5859H24.2266Z"
                fill="white"
              />
            </div>
            <h4 class="mb-3 text-xl font-bold text-dark">
              코로나 이전 매출 20% 뛰어넘은 서울 전통시장..위기 극복 비결은?
            </h4>
            <p class="mb-8 text-body-color lg:mb-11">
              자영업자와 소상공인들이 어려움을 겪는 코로나19 기간에 서울
              영등포구 영등포청과시장 매출은 오히려 급증했다.
            </p>
            <a
              target="_blank"
              href="https://www.mk.co.kr/news/society/view/2022/05/458913/"
              class="text-base font-medium text-body-color hover:text-primary"
            >
              뉴스 보러 가기
            </a>
          </div>
        </div>
        <div class="w-full px-4 md:w-1/2 lg:w-1/4">
          <div class="wow fadeInUp group mb-12 bg-white" data-wow-delay=".25s">
            <div
              class="
                relative
                z-10
                mb-8
                flex
                h-[70px]
                w-[70px]
                items-center
                justify-center
                rounded-2xl
              "
              style="background-color: #786d64"
            >
              <span
                class="
                  absolute
                  top-0
                  left-0
                  z-[-1]
                  mb-8
                  flex
                  h-[70px]
                  w-[70px]
                  rotate-[25deg]
                  items-center
                  justify-center
                  rounded-2xl
                  bg-opacity-20
                  duration-300
                  group-hover:rotate-45
                "
                style="background-color: #786d64"
              ></span>
              <span class="mb-2 block text-lg font-semibold text-white">
                증권
              </span>
            </div>
            <h4 class="mb-3 text-xl font-bold text-dark">
              운임상승, 중국 경기부양...해운주 이달 들어 강세 이어가
            </h4>
            <p class="mb-8 text-body-color lg:mb-11">
              해운주가 약세장 가운데서도 순항하고 있다. 한동안 주가 부진의
              원인으로 작용했던 운임 피크아웃(고점 통과) 우려가...
            </p>
            <a
              target="_blank"
              href="https://www.mk.co.kr/news/stock/view/2022/05/458486/"
              class="text-base font-medium text-body-color hover:text-primary"
            >
              뉴스 보러 가기
            </a>
          </div>
        </div>
      </div>
    </div>
    <!-- ====== Features Section End -->
  </div>
</template>

<script>
import { Hooper, Slide } from "hooper";
import "hooper/dist/hooper.css";
export default {
  components: { Hooper, Slide },
};
</script>

<style scoped>
.container {
  margin-top: 50px;
}
.image-thumbnail {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
</style>
