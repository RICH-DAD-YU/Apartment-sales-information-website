package com.mycom.happy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappyHouse5SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(HappyHouse5SpringApplication.class, args);
	}

}
